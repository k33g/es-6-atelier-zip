/*--- Request ---*/
/* === Spécifications ===

Utilisation de Request:


Ajouter 4 méthodes à la classe Request:

- get() retourne une promise via sendRequest() avec la propriété method = "GET"
- post(jsonData) retourne une promise via sendRequest() avec la propriété method = "POST" et la propriété data prend la valeur jsonData
- put(jsonData) retourne une promise via sendRequest() avec la propriété method = "PUT" et la propriété data prend la valeur jsonData
- delete() retourne une promise via sendRequest() avec la propriété method = "DELETE"

*/
class Request {

  constructor (url = "/") {
    this.request = new XMLHttpRequest();
    this.url = url;
    this.method = null;
    this.data = null;
  }

  sendRequest () { /*json only*/

    return new Promise((resolve, reject) => {
      this.request.open(this.method, this.url);
      this.request.onload = () => {
        // If the request was successful
        if (this.request.status === 200) {
          resolve(JSON.parse(this.request.response)); // JSON response
        } else { /* oups */
          reject(Error(this.request.statusText));
        }
      }
      // Handle network errors
      this.request.onerror = function() {
        reject(Error("Network Error"));
      };

      this.request.setRequestHeader("Content-Type", "application/json");
      this.request.send(this.method === undefined ? null : JSON.stringify(this.data));
    });
  }

  /*--- Ajouter vos méthodes ici ---*/

}

export default Request;
