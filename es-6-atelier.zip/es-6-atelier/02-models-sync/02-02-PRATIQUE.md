#ES6 - Partie 2 : Exercice 2: On parle avec le serveur

##Objectifs:

Donner la possibilité aux modèles et aux collections d'échanger des informations de persistence avec le serveur:

- compléter `Request.js`, La classe `Request` nous permettra de faire des requêtes ajax
- compléter `Model.js`
- compléter `Collection.js`
- Modifier `Human.js`
- Modifier `Humans.js`


##Exercice

**Remarque**: les spécifications sont décrites dans les fichiers

Stoppez l'exercice 1, puis:

    cd ..
    cd 02-models-sync
    node app.js
    http://localhost:3000



