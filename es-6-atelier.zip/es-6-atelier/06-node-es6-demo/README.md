#ES6 + Node

