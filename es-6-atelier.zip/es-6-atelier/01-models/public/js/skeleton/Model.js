/*--- model ---*/

/* === Spécifications ===
une classe Model

Paramètres du constructeur:

- fields, valeur par défaut {}, contiendra les "champs" du model, ex: {firstName:"Bob", lastName:"Morane"}
- observers, valeur par défaut []

Propriétés:

- fields : initialisé par le paramètre correspondant du constructeur
- observers : initialisé par le paramètre correspondant du constructeur

Méthodes:

- addObserver (observer)
- notifyObservers (context)
- get (fieldName), va lire la valeur d'un champ dans fields
- set (fieldName, value), va modifier la valeur d'un champ dans fields
- toString (), retourne une représentation json de fields

un observer est juste un objet avec une méthode update
donc notifyObservers execute la méthode update de tous les observers avec context en paramètre


*/

class Model {

}

export default Model;

