/* === Spécifications ===
une classe Humans qui hérite de Collection

Paramètres du constructeur:

- humans, un tableau de modèles

Propriétés:

- initialiser la propriété model de la classe mère avec le type Human
- initialiser la propriété models de la classe mère avec le paramètre humans du constructeur

Méthodes:

- sans objet
*/
