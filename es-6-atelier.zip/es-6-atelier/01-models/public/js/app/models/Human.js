/* === Spécifications ===
une classe Human qui hérite de Model

Paramètres du constructeur:

- fields, valeur par défaut {firstName:"John", lastName:"Doe"},

Propriétés:

- initialiser la propriété fields de la classe mère avec le paramètre du constructeur

Getters & Setters pour :

- firstName -> set or get of this.fields.firstName
- lastName -> set or get of this.fields.lastName

Méthodes:

- sans objet

 */
import Model from '../../skeleton/Model';