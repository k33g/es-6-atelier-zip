#ES6 - Partie 4 : Exercice 4: Le routeur

##Objectifs:

Créer un routeur qui "écoutera" le navigateur :

- click sur un lien (met à jour window.location.hash)
- saisie d'url (met à jour window.location.hash)
- bouton back (met à jour window.location.hash)

Ce routeur contiendra des routes (couple url, traitement), si l'url d'une route = window.location.hash,
alors le traitement correspondant est déclenché

##Exercice

**Remarque**: les spécifications sont décrites dans les fichiers

Stoppez l'exercice 3, puis:
    
    cd ..
    cd 04-router
    node app.js
    http://localhost:3000



