#Atelier ES6

Création d'un framework MVC en ES6
Décrire tout ce que nous allons faire
Bien sûr nous ne verrons pas tout
si nous n'arrivons pas au bout : pinguer moi ici : ph.charriere@gmail.com

Notre framework s'appelera "skeleton"

